#!/usr/bin/python

import random

filehandle= open( 'universe.txt')

testList=filehandle.readlines()

random.shuffle(testList)

filehandle.close()

filehandle= open( 'random_case.txt', 'a')
for testcase in testList:
    filehandle.write(testcase)
filehandle.close()
