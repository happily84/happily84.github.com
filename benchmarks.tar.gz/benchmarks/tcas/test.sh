#!/bin/bash

# S1 is the name of program
# S2 is the name of input file
# S3 is the type of coverage criteria

make clean

make

if [ "$3" == "s" ];then

	echo ==========================
	echo It\'s a Statement Coverage
	echo ==========================

	cat $2| while read line;
	do
		./$1 $line > /dev/null
	done

	gcov $1

elif [ "$3" == "b" ];then

	echo ==========================
	echo It\'s a Branch Coverage
	echo ==========================

	cat $2| while read line;
	do
		./$1 $line
	done

	gcov -b -c $1 
else
	echo What the fuck
fi

exit 0
