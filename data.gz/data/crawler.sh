#!/bin/bash
echo crawler for fetching data from twitter according to Twitter2011 REC data-set
#$1 means the name of data-set
#$2 means proxy file

#load data-set

if ! test -e $1;then
	echo "File $1 not found." && exit 0
else
	echo "File $1 loaded successful."
fi

#rm goodproxy.ini
#./verifyProxy.sh
cp $1 $1.$(date +%b%d-%M%S)

Tweet_number_list=$(cat $1 |cut -f 1)
Tweet_owner_list=$(cat $1 |cut -f 2)

#for i in $Tweet_code_number
#do
#	echo "$i test"
#done

#echo "$Tweet_code_number"
declare -i cnt=0
declare -i proxynum=0
declare -i count=0
declare -i countt=0
function changeProxy {
	proxylist=$(cat proxy.ini|cut -f 1)
#	echo "$proxylist"
	for proxy in $proxylist
	do
#		if [ $proxynum -gt 100 ];then
#			echo proxynum is $proxynum
#			echo error. no proxy availble now.
#			exit 0
#		fi

		if test $cnt -eq $proxynum;then
			cnt=0
			return 0
		else
			cnt=cnt+1
		fi
	done
}

#echo $cnt $num $proxy

for Tweet_number in $Tweet_number_list 
do
#echo "http://api.twitter.com/1/statuses/show/$Tweet_number.json"
#	echo $countt countt
#	count=count+1
#	countt=count%120
#	if test $countt -eq 1;then
#		proxynum=proxynum+1
#		proxynum=proxynum%10
	if [ $proxynum = 395 ];then
		proxynum=0
	fi

	if [ $count = 0 ];then
		proxynum=proxynum+1
		changeProxy
	fi
#	echo $count tweets fetched, change proxy.
#	echo -ne "\n"
#	fi
#echo $num num
#	echo $count count
#	echo $proxy
	result=$(curl -s -x http://$proxy http://api.twitter.com/1/statuses/show/$Tweet_number.json)
	
#verify the data
	result_head=$(echo $result|cut -c 3-8)
	result_nail=$(echo $result|cut -c 67-70)
#	echo Fuck $result_nail 
	if [ "$result_head" = "create" ];then
		echo The $count tweets $Tweet_number fetched success!
	elif [ "$result_head" = "errors" ];then
		echo The $count tweets $Tweet_number server error.
	elif [ "$result_nail" = "Sorr" ];then
		echo The $count tweets is unknow error.
#		echo $result
#		echo $result_nail
	else
		echo The $count tweets $Tweet_number fetch failure.	
		while [ "$result_head" != "create" -a "$result_head" != "errors" -a "$result_head" != "Sorr" ]
		do
			echo $result
			echo $proxy does not work, change a proxy.
			proxynum=proxynum+1
			changeProxy
			echo current proxy is :$proxy
			result=$(curl -m 10 -s -x http://$proxy http://api.twitter.com/1/statuses/show/$Tweet_number.json)
			result_head=$(echo $result|cut -c 3-8)
			result_nail=$(echo $result|cut -c 67-70)
		done
	fi
		
#	echo $result
#	echo http://$proxy http://api.twitter.com/1/statuses/show/$Tweet_number.json 
	count=count+1
	echo -ne $result "\n" >> $2
	sed -i "1d" $1
done

exit 0


