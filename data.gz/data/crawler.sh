#!/bin/bash
echo crawler for fetching data from twitter according to Twitter2011 REC data-set
#$1 means the name of data-set
#$2 means proxy file

#load data-set

if ! test -e $1;then
	echo "File $1 not found." && exit 0
else
	echo "File $1 loaded successful."
fi

Tweet_number_list=$(cat $1 |cut -f 1)
Tweet_owner_list=$(cat $1 |cut -f 2)

#for i in $Tweet_code_number
#do
#	echo "$i test"
#done

#echo "$Tweet_code_number"
declare -i cnt=0
declare -i proxynum=0
declare -i count=0
declare -i countt=0
function changeProxy {
	proxylist=$(cat goodproxy.ini)
#	echo "$proxylist"
	for proxy in $proxylist
	do
		if test $cnt -eq $proxynum;then
			cnt=0
			return 0
		else
			cnt=cnt+1
		fi
	done
}

#echo $cnt $num $proxy

for Tweet_number in $Tweet_number_list 
do
echo "http://api.twitter.com/1/statuses/show/$Tweet_number.json"
#	echo $countt countt
	count=count+1
	countt=count%120
	if test $countt -eq 1;then
		proxynum=proxynum+1
		proxynum=proxynum%10
	changeProxy
	echo $count tweets fetched, change proxy.
	echo -ne "\n"
	fi
#echo $num num
#	echo $count count
#	echo $proxy
	curl -x http://$proxy http://api.twitter.com/1/statuses/show/$Tweet_number.json >> $2
#	echo http://$proxy http://api.twitter.com/1/statuses/show/$Tweet_number.json 
	echo -ne "\n" >> $2
done

exit 0


