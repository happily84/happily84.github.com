#!/bin/bash
echo crawler for fetching data from twitter according to Twitter2011 REC data-set
#$1 means the name of data-set
#$2 means proxy file

#load data-set

proxyList=$(cat proxy.ini|cut -f 1)

for proxy in $proxyList
do
	test1=$(curl -m 3 -x http://$proxy http://api.twitter.com/1/statuses/show/28965131362770944.json)
	echo $test1 > 1.tmp
	test2=$(cut -c 3-9 1.tmp)
	if [ -z $test2 ];then
		echo $proxy 
	elif [ "$test2" = "created" ];then
		echo $proxy >> goodproxy.ini 
	elif [ "$test2" = "timeout" ];then
		echo $proxy >> timelimitproxy.ini 
	else
		echo fffffffffffffuck 
	fi
#Todo: examine which proxy is avialuble.
done
rm 1.tmp
exit 0


